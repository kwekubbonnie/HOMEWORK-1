#Kweku Agyeman Baffoe Bonnie
#Assignment 1
#Question 1

import random
import numpy  
  

A = [] 
B = [] 


def DotProd(N, ListA, ListB): 
  
    
  
    #this is a loop that runs to calculate the product.
    for i in range(N):  
        first = random.randint(1, 1000)  
        ListA.append(first)  
    for j in range(N):  
        second = random.randint(1, 1000)  
        ListB.append(second)  


    value = numpy.dot(ListA, ListB)  

    
    print("List A:", ListA)
    print("List B:", ListB)
    print("The size of your array is:", N)
    print("The dot product is:", result)  


DotProd(, A, B)  
DotProd(, A, B)
